package com.pbe.soda_caustica_flanges.repository;

import com.pbe.soda_caustica_flanges.model.Flange;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FlangeRepository extends JpaRepository<Flange, Long> {
}
