package com.pbe.soda_caustica_flanges.controller;

import com.pbe.soda_caustica_flanges.model.Funcionario;
import com.pbe.soda_caustica_flanges.repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/funcionario")
public class FuncionarioController {

    @Autowired
    private FuncionarioRepository repository;

    @GetMapping("/cadastro")
    public String formCadastro(Model model) {
        model.addAttribute("funcionario", new Funcionario());
        return "funcionario/cadastro";
    }

    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Funcionario funcionario, RedirectAttributes attributes) {
        repository.save(funcionario);
        attributes.addFlashAttribute("mensagem", "Funcionário processado com sucesso!");
        return "redirect:/funcionario/listagem";
    }

    @GetMapping("/listagem")
    public String listar(Model model) {
        model.addAttribute("funcionarios", repository.findAll());
        return "funcionario/listagem";
    }

    @GetMapping("/editar/{id}")
    public String formEditar(@PathVariable Long id, Model model) {
        Funcionario func = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("ID inválido"));
        model.addAttribute("funcionario", func);
        return "funcionario/editar";
    }

    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, RedirectAttributes attributes) {
        repository.deleteById(id);
        attributes.addFlashAttribute("mensagem", "Funcionário removido do sistema.");
        return "redirect:/funcionario/listagem";
    }
}